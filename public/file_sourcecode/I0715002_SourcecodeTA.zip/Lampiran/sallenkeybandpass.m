%keterangan Nilai Komponen
R1 = 4.7e3;
R2 = 10e3;
R3 = 33e3;
Ra = 33e3;
Rb = 33e3;
C1 = 22e-9;
C2 = 4.7e-9;
%O=C1; %Apabila Nilai C1=C2
%O=C2;

u = 1+(Rb/Ra) 
A = R1+R2;
L = R1*R2*R3*C1*C2;
E = R1+R3;
F = R1*R2*R3;

Z = E/F
Y = sqrt(Z)
X = Y/(2*pi*1500)

Wo2 = (A/L)
Wo = sqrt(Wo2)

C = ((1/(R1*C1))+(1/(R3*C2))+(1/(R3*C1))+((1-u)/(R2*C1)))
Q = Wo/C %menghitung nilai kualitas dari filter

D = u/(R1*C1)
G = D/C %menghitung gain dari filter

L = (C1+C2)/2;
K = 1/(2*pi)
J = sqrt(A/F);
Ao = R2/(2*R1);
f1 = Q/(2*pi*L*Ao*R1)
f2 = Q/(pi*R2*Ao*L)
f3 = Q/(2*pi*R3*L*((2*(Q^2))-Ao))
fc = K*Wo %menghitung frekuensi cutoff
BW = f1/Q %menghitung bandwidth

X = [D 0];
Y = [1 C Wo2];
L = tf([X],[Y]) %menghitung fungsi transfer

bode(L) %bode plot