%clc
clear all

A = '10kHz.csv';
M = csvread(A);

Fs = 44.1e3;
L = 1000;
t = 0:1/Fs:1;

%%
nharm = 6;
[thd_db,harmpow,harmfreq] = thd(M,Fs,nharm);

%%
percent_thd = 100*(10^(thd_db/20))

%%
T = table(harmfreq,harmpow,'VariableNames',{'Frequency','Power'})

%%
thd(M,Fs,nharm);