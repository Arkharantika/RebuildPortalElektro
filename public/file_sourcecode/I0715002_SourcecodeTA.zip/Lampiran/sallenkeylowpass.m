%keterangan Nilai Komponen
R1 = 15e3;
R2 = 15e3;
Ra = 12e3;
Rb = 15e3;
C1 = 47e-9;
C2 = 47e-9;

u = 1+(Rb/Ra);
G = u %G=u, merupakan penguatan filter
A = R1*R2*C1*C2;
B = sqrt(R1*R2*C1*C2)

Wo2 = 1/(R1*R2*C1*C2)
Wo = sqrt(Wo2)

C = ((1/(R1*C1))+(1/(R2*C1))+((1-u)/(R2*C2)))
Q = (1/(B))/C %menghitung kualitas filter

fc = 1/(2*pi*B) %menghitung frekuensi cutoff
f =(2*pi*B)
X = [u/A];
Y = [1 C Wo2];
L = tf([X],[Y]) %merupakan fungsi transfer filter

bode(L) %bode plot